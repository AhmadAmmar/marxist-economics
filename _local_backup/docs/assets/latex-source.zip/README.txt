Build instructions:

1) Upload these .tex files to Overleaf or compile locally with LaTeX.
2) Main entry point: main.tex.
